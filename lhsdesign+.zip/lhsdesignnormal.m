function[LHSMatrix] = lhsdesignnormal(n,mu,sigma,p)

%% Description of Function, Inputs, and Outputs
% This function, and the others found in this file, serve as specialized
% means of obtaining a Latin hypercube sample from each of Matlab's
% supported distribution types. This function allows the user to take Latin
% hypercube samples from specified normal distributions. This is dissimilar
% to Matlab's "lhsdesign" in that this function allows the user to sample
% from a specialized distribution type, subject to input parameters, and
% choose an iterative number of n x 1 runs of this sampling procedure. 

% This function supports a variable number of input arguments and the
% inputs are defined as follows. n denotes the number of sample points, mu
% and sigma are the normal distribution parameters (more information available
% through MathWorks documentation on 'Normal Distribution'), and p is the
% optional number of iterative runs of the sampling procedure. The function
% output, LHSMatrix, is either an array containing the Latin hypercube
% sample or a p x 1 cell structure, depending on the input for p.

%% LHS and Applications
% Latin hypercube sampling is a method of stratified random sampling which
% is useful as an alternative to Monte Carlo techniques in many cases, due
% to its nature of requiring a far smaller sample size to achieve
% comparable accuracy. 

%% Development and Author Information
%
% * Developed in Matlab 2022a, expected compatability with all versions
%   later than Matlab 2010b, requires Statistics and Machine Learning 
%   Toolbox
%
% * Tristen M Jackson, Florida State University, tjackson@math.fsu.edu
%       All rights reserved
%
% * Last Modified: October 1, 2022


i=1;
j=1;

function r=rank(LHSMatrix)
   [sx, rowidx] = sort(LHSMatrix);
   r(rowidx) = 1:length(LHSMatrix);
   r = r(:);
end

    if nargin == 0
        error('Not enough input arguments')
    end 


    if nargin == 1
            mu=0; sigma=1;
            z = normrnd(mu,sigma,n,1);
            LHSMatrix = zeros(size(z));
            LHSMatrix(:,1) = rank(z(:,1));
            LHSMatrix = (LHSMatrix - rand(size(LHSMatrix)))/n;

            LHSMatrix(:,1) = norminv(LHSMatrix,mu,sigma);

            [sx, rowidx] = sort(LHSMatrix);
            r(rowidx) = 1:length(LHSMatrix);
            r = r(:);
    
        histogram(LHSMatrix, 'Normalization', 'probability');
        title("Histogram of LHS");
        xlabel("Bin");
        ylabel("Counts");
        fprintf("Only one input argument supplied. Producing an LHS array assuming mu = 0, sigma = 1.")
    end


    if nargin == 2
        error('Invalid number of input arguments')
    end


    if nargin == 3
        z = normrnd(mu,sigma,n,1);
            LHSMatrix = zeros(size(z));
            LHSMatrix(:,1) = rank(z(:,1));
            LHSMatrix = (LHSMatrix - rand(size(LHSMatrix)))/n;

            LHSMatrix(:,1) = norminv(LHSMatrix,mu,sigma);

            [sx, rowidx] = sort(LHSMatrix);
            r(rowidx) = 1:length(LHSMatrix);
            r = r(:);
    
        histogram(LHSMatrix, 'Normalization', 'probability');
        title("Histogram of LHS");
        xlabel("Bin");
        ylabel("Counts");
    end


    if nargin == 4
        LHSMatrix = cell(p,1)
        for j = 1:p
            z = normrnd(mu,sigma,n,1);
            LHSMatrix = zeros(size(z));
            LHSMatrix(:,1) = rank(z(:,1));
            LHSMatrix = (LHSMatrix - rand(size(LHSMatrix)))/n;

            LHSMatrix(:,1) = norminv(LHSMatrix,mu,sigma);

            [sx, rowidx] = sort(LHSMatrix);
            r(rowidx) = 1:length(LHSMatrix);
            r = r(:);
            PlaceHolder{j} = LHSMatrix
        end
           
    
        histogram(LHSMatrix, 'Normalization', 'probability');
        title("Histogram of One Iteration of LHS");
        xlabel("Bin");
        ylabel("Counts");
        LHSMatrix = PlaceHolder
    end


    if nargin > 4
        error('Invalid number of input arguments')
    end
end